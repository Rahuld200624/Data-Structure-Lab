# Data Structures Lab Programs (C)

This repository contains Data Structures lab programs extracted from the supplied lab manual.

## array_operations.c
Derived from 1. Implement basic array operations: insertion, deletion, searching, and traversal.

## sparse_matrix_triplet.c
Derived from 2. Represent a sparse matrix using triplet form and perform transpose operation.

## stack_array.c
Derived from 3. Implement stack operations using arrays and linked lists.

## stack_linked_list.c
Derived from 3. Implement stack operations using arrays and linked lists.

## infix_to_postfix.c
Derived from 4.Convert an infix expression to postfix using a stack.

## postfix_evaluation.c
Derived from 5. Evaluate a postfix expression using a stack.

## queue_array.c
Derived from 6. Implement queue operations using arrays and linked lists.

## queue_linked_list.c
Derived from 6. Implement queue operations using arrays and linked lists.

## circular_queue.c
Derived from 7.Implement a circular queue using arrays.

## priority_queue.c
Derived from 8. Implement a priority queue using arrays or linked lists.

## singly_linked_list.c
Derived from 9. Implement singly linked list operations: insertion, deletion, and search.

## binary_tree_traversal.c
Derived from 10. Implement binary tree creation and traversal (preorder, inorder, postorder).

## graph_adjacency_matrix.c
Derived from 11. Represent a graph using adjacency matrix and adjacency list.

## graph_adjacency_list.c
Derived from 11. Represent a graph using adjacency matrix and adjacency list.

## bfs_dfs.c
Derived from 12. Implement graph traversal: BFS and DFS.


## Sample Outputs

- Infix `(A+B)*C` → Postfix `AB+C*`
- Postfix `23*5+` → Result `11`
- Binary Tree Traversals:
  - Preorder: `1 2 4 5 3`
  - Inorder: `4 2 5 1 3`
  - Postorder: `4 5 2 3 1`
